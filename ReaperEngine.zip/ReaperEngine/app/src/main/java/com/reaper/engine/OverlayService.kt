package com.reaper.engine

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.Switch
import android.widget.TextView
import androidx.core.app.NotificationCompat
import java.net.DatagramPacket
import java.net.DatagramSocket
import android.graphics.PointF

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var menuView: View
    private lateinit var espCanvas: ESPCanvas

    private var udpSocket: DatagramSocket? = null
    private var udpThread: Thread? = null
    private var running = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(42, buildNotification())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        setupESPCanvas()
        setupMenu()
        startUDPListener()
    }

    // --- ESP Canvas (tam ekran, dokunulamaz) ---
    private fun setupESPCanvas() {
        espCanvas = ESPCanvas(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(espCanvas, params)
    }

    // --- Floating Menü ---
    private fun setupMenu() {
        menuView = LayoutInflater.from(this).inflate(R.layout.overlay_menu, null)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20
            y = 150
        }

        // drag
        var dX = 0f; var dY = 0f
        menuView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    dX = params.x - event.rawX
                    dY = params.y - event.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = (event.rawX + dX).toInt()
                    params.y = (event.rawY + dY).toInt()
                    wm.updateViewLayout(menuView, params)
                }
            }
            true
        }

        // Player ESP toggle
        val espSwitch = menuView.findViewById<Switch>(R.id.switchPlayerEsp)
        espSwitch.setOnCheckedChangeListener { _, checked ->
            espCanvas.enabled = checked
        }

        wm.addView(menuView, params)
    }

    // --- UDP Listener: Lua script'ten veri al ---
    private fun startUDPListener() {
        running = true
        udpThread = Thread {
            try {
                udpSocket = DatagramSocket(7777)
                val buf = ByteArray(65535)
                val packet = DatagramPacket(buf, buf.size)

                while (running) {
                    udpSocket!!.receive(packet)
                    val msg = String(packet.data, 0, packet.length)
                    parseAndUpdate(msg)
                }
            } catch (e: Exception) {
                // socket kapandı
            }
        }.also { it.isDaemon = true; it.start() }
    }

    // --- Lua'dan gelen veriyi parse et ---
    // format: ESP:player1data##player2data:VPORT:w,h
    private fun parseAndUpdate(msg: String) {
        try {
            if (!msg.startsWith("ESP:")) return

            val vportIdx = msg.indexOf(":VPORT:")
            val espPart   = if (vportIdx > 0) msg.substring(4, vportIdx) else msg.substring(4)
            val vportPart = if (vportIdx > 0) msg.substring(vportIdx + 7) else null

            vportPart?.let {
                val parts = it.split(",")
                if (parts.size == 2) {
                    val vw = parts[0].toFloatOrNull() ?: return@let
                    val vh = parts[1].toFloatOrNull() ?: return@let
                    espCanvas.robloxVP = PointF(vw, vh)
                }
            }

            if (espPart.isBlank()) {
                espCanvas.players = listOf()
                return
            }

            val playerList = mutableListOf<ESPCanvas.ESPPlayer>()

            for (entry in espPart.split("##")) {
                if (entry.isBlank()) continue
                // NAME;X;Y;W;H;DIST;HP;j0|j1|...|j11
                val parts = entry.split(";")
                if (parts.size < 8) continue

                val name  = parts[0]
                val x     = parts[1].toFloatOrNull() ?: continue
                val y     = parts[2].toFloatOrNull() ?: continue
                val w     = parts[3].toFloatOrNull() ?: continue
                val h     = parts[4].toFloatOrNull() ?: continue
                val dist  = parts[5].toIntOrNull() ?: continue
                val hp    = parts[6].toIntOrNull() ?: 100
                val jointStr = parts[7]

                val joints = mutableListOf<PointF>()
                for (jToken in jointStr.split("|")) {
                    val jParts = jToken.split(",")
                    if (jParts.size == 3) {
                        val jx = jParts[0].toFloatOrNull() ?: 0f
                        val jy = jParts[1].toFloatOrNull() ?: 0f
                        val on = jParts[2] == "1"
                        joints.add(if (on) PointF(jx, jy) else PointF(0f, 0f))
                    }
                }

                playerList.add(ESPCanvas.ESPPlayer(name, x, y, w, h, dist, hp, joints))
            }

            espCanvas.players = playerList

        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        super.onDestroy()
        running = false
        udpSocket?.close()
        udpThread?.interrupt()
        if (::menuView.isInitialized) wm.removeView(menuView)
        if (::espCanvas.isInitialized) wm.removeView(espCanvas)
    }

    private fun buildNotification(): Notification {
        val ch = NotificationChannel("reaper_ch", "ReaperEngine", NotificationManager.IMPORTANCE_LOW)
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        return NotificationCompat.Builder(this, "reaper_ch")
            .setContentTitle("ReaperEngine")
            .setContentText("ESP aktif")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
    }
}
