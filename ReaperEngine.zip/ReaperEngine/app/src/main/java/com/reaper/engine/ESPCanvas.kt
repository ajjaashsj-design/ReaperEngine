package com.reaper.engine

import android.content.Context
import android.graphics.*
import android.view.View

class ESPCanvas(context: Context) : View(context) {

    var enabled = false

    data class ESPPlayer(
        val name: String,
        val x: Float,
        val y: Float,
        val w: Float,
        val h: Float,
        val dist: Int,
        val hp: Int,
        val joints: List<PointF>
    )

    @Volatile
    var players: List<ESPPlayer> = listOf()

    // viewport Roblox'tan geliyor, scale için
    @Volatile
    var robloxVP: PointF = PointF(1920f, 1080f)

    private val boxPaint = Paint().apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 2f
        isAntiAlias = true
    }

    private val tracerPaint = Paint().apply {
        color = Color.GREEN
        strokeWidth = 2f
        isAntiAlias = true
    }

    private val skeletonPaint = Paint().apply {
        color = Color.rgb(255, 80, 80)
        strokeWidth = 1.8f
        isAntiAlias = true
    }

    private val textPaint = Paint().apply {
        color = Color.WHITE
        textSize = 30f
        typeface = Typeface.DEFAULT_BOLD
        isAntiAlias = true
        setShadowLayer(4f, 1f, 1f, Color.BLACK)
    }

    private val hpGreenPaint = Paint().apply {
        color = Color.GREEN
        style = Paint.Style.FILL
    }

    private val hpBgPaint = Paint().apply {
        color = Color.rgb(30, 30, 30)
        style = Paint.Style.FILL
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!enabled) {
            postInvalidateDelayed(16)
            return
        }

        val scaleX = width / robloxVP.x
        val scaleY = height / robloxVP.y
        val centerX = width / 2f

        for (p in players) {
            if (p.dist > 280) continue

            val sx = p.x * scaleX
            val sy = p.y * scaleY
            val sw = p.w * scaleX
            val sh = p.h * scaleY

            val left   = sx - sw / 2f
            val right  = sx + sw / 2f
            val top    = sy
            val bottom = sy + sh

            // BOX
            canvas.drawRect(left, top, right, bottom, boxPaint)

            // İSİM + MESAFE
            canvas.drawText("${p.name} [${p.dist}m]", left, top - 6f, textPaint)

            // TRACER — ekranın üst ortasından ayağa
            canvas.drawLine(centerX, 0f, sx, bottom, tracerPaint)

            // HP BAR (sol kenar)
            val barX    = left - 6f
            val barW    = 4f
            val hpRatio = p.hp / 100f
            canvas.drawRect(barX, top, barX + barW, bottom, hpBgPaint)
            val hpColor = Color.rgb(
                (255 * (1f - hpRatio)).toInt(),
                (255 * hpRatio).toInt(),
                0
            )
            hpGreenPaint.color = hpColor
            canvas.drawRect(barX, top + sh * (1f - hpRatio), barX + barW, bottom, hpGreenPaint)

            // SKELETON
            val j = p.joints
            if (j.size >= 12) {
                val sj = j.map { PointF(it.x * scaleX, it.y * scaleY) }
                drawBone(canvas, sj[0], sj[1])   // head → upperTorso
                drawBone(canvas, sj[1], sj[2])   // → lUpperArm
                drawBone(canvas, sj[1], sj[3])   // → rUpperArm
                drawBone(canvas, sj[2], sj[4])   // lUpperArm → lLowerArm
                drawBone(canvas, sj[3], sj[5])   // rUpperArm → rLowerArm
                drawBone(canvas, sj[1], sj[6])   // torso → lUpperLeg
                drawBone(canvas, sj[1], sj[7])   // torso → rUpperLeg
                drawBone(canvas, sj[6], sj[8])   // lUpperLeg → lLowerLeg
                drawBone(canvas, sj[7], sj[9])   // rUpperLeg → rLowerLeg
                drawBone(canvas, sj[8], sj[10])  // lLowerLeg → lFoot
                drawBone(canvas, sj[9], sj[11])  // rLowerLeg → rFoot
            }
        }

        postInvalidateDelayed(16)
    }

    private fun drawBone(canvas: Canvas, a: PointF, b: PointF) {
        if (a.x == 0f && a.y == 0f) return
        if (b.x == 0f && b.y == 0f) return
        canvas.drawLine(a.x, a.y, b.x, b.y, skeletonPaint)
    }
}
