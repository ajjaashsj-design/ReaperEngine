package com.reaper.engine

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.io.File

class DashboardActivity : AppCompatActivity() {

    private val ROBLOX_PKG = "com.roblox.client"
    private val games = mutableListOf<String>()
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        val listView = findViewById<ListView>(R.id.gameList)
        val addBtn   = findViewById<FloatingActionButton>(R.id.addGameBtn)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, games)
        listView.adapter = adapter

        // overlay izni iste
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, 1001)
        }

        addBtn.setOnClickListener { addRoblox() }

        listView.setOnItemClickListener { _, _, pos, _ ->
            launchWithInject(games[pos])
        }
    }

    private fun addRoblox() {
        try {
            packageManager.getPackageInfo(ROBLOX_PKG, 0)
            if (!games.contains("Roblox")) {
                games.add("Roblox")
                adapter.notifyDataSetChanged()
                Toast.makeText(this, "Roblox eklendi.", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Zaten ekli.", Toast.LENGTH_SHORT).show()
            }
        } catch (e: PackageManager.NameNotFoundException) {
            Toast.makeText(this, "Roblox yüklü değil!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun launchWithInject(game: String) {
        // ESP lua scriptini SD karta yaz
        writeESPScript()

        // Overlay servisini başlat
        val svcIntent = Intent(this, OverlayService::class.java)
        startForegroundService(svcIntent)

        // Roblox'u aç
        val launchIntent = packageManager.getLaunchIntentForPackage(ROBLOX_PKG)
        if (launchIntent != null) {
            startActivity(launchIntent)
            Toast.makeText(this, "Roblox açılıyor, ESP hazır.", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Roblox başlatılamadı.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun writeESPScript() {
        try {
            val dir = Environment.getExternalStorageDirectory()
            val file = File(dir, "reaper_esp.lua")
            file.writeText(ESP_SCRIPT)
            Toast.makeText(this, "Script: ${file.absolutePath}", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Script yazılamadı: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    companion object {
        // Roblox executor'a yüklenecek Lua script
        // UDP 127.0.0.1:7777 -> OverlayService
        val ESP_SCRIPT = """
-- ReaperEngine ESP Script
-- Bu scripti executor'a yapistir
-- Koordinatlari Android overlay'e UDP ile gonderir

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local Camera = workspace.CurrentCamera
local LocalPlayer = Players.LocalPlayer
local MAX_DIST = 280

local socket = nil
pcall(function()
    socket = require("socket")
end)

local udp = nil
pcall(function()
    udp = socket.udp()
    udp:setpeername("127.0.0.1", 7777)
    udp:settimeout(0)
end)

local function worldToScreen(pos)
    local s, onScreen = Camera:WorldToViewportPoint(pos)
    return Vector2.new(s.X, s.Y), onScreen, s.Z
end

local function sendData(data)
    if udp then
        pcall(function() udp:send(data) end)
    end
end

local function getJoints(character)
    local joints = {}
    local partNames = {
        "Head", "UpperTorso", "LeftUpperArm", "RightUpperArm",
        "LeftLowerArm", "RightLowerArm",
        "LeftUpperLeg", "RightUpperLeg",
        "LeftLowerLeg", "RightLowerLeg",
        "LeftFoot", "RightFoot"
    }
    for _, name in ipairs(partNames) do
        local part = character:FindFirstChild(name)
        if part then
            local s, on = Camera:WorldToViewportPoint(part.Position)
            table.insert(joints, string.format("%.1f,%.1f,%s", s.X, s.Y, on and "1" or "0"))
        else
            table.insert(joints, "0,0,0")
        end
    end
    return table.concat(joints, "|")
end

RunService.RenderStepped:Connect(function()
    local vp = Camera.ViewportSize
    local playerData = {}

    for _, player in ipairs(Players:GetPlayers()) do
        if player == LocalPlayer then continue end
        local char = player.Character
        if not char then continue end

        local root = char:FindFirstChild("HumanoidRootPart")
        local head = char:FindFirstChild("Head")
        local hum  = char:FindFirstChildOfClass("Humanoid")
        if not root or not head or not hum then continue end

        local dist = (Camera.CFrame.Position - root.Position).Magnitude
        if dist > MAX_DIST then continue end

        local topPos = head.Position + Vector3.new(0, head.Size.Y / 2, 0)
        local botPos = root.Position - Vector3.new(0, root.Size.Y / 2, 0)

        local topS, onScreen = Camera:WorldToViewportPoint(topPos)
        local botS = Camera:WorldToViewportPoint(botPos)

        if not onScreen then continue end

        local h = math.abs(topS.Y - botS.Y)
        local w = h * 0.6
        local hp = math.floor((hum.Health / math.max(hum.MaxHealth, 1)) * 100)
        local joints = getJoints(char)

        -- format: NAME;X;Y;W;H;DIST;HP;JOINTS
        table.insert(playerData, string.format("%s;%.1f;%.1f;%.1f;%.1f;%d;%d;%s",
            player.Name,
            topS.X, topS.Y,
            w, h,
            math.floor(dist),
            hp,
            joints
        ))
    end

    local msg = "ESP:" .. table.concat(playerData, "##") .. ":VPORT:" .. vp.X .. "," .. vp.Y
    sendData(msg)
end)

print("[ReaperEngine] ESP aktif - UDP 7777")
""".trimIndent()
    }
}
