# ReaperEngine v1.0 — ESP Edition

## Kurulum

### GitHub'dan APK build alma
1. Bu repoyu fork'la
2. Actions sekmesine gir → "Build APK" → "Run workflow"
3. Build bittikten sonra Artifacts'tan `ReaperEngine-v1-debug.apk` indir

### APK yükleme
1. Android'de **Bilinmeyen kaynaklara izin ver**
2. APK'yı yükle
3. Uygulamayı aç

---

## Kullanım

### 1. Lisans
- Uygulama açılır, **Lisans Girin** kutusuna: `ReaperEngine`
- DOĞRULA'ya bas

### 2. Oyun Ekle
- Dashboard'da **+ butonuna** bas
- Roblox yüklüyse listeye eklenir

### 3. ESP Aktifleştirme
- Overlay izni iste — **İzin Ver**
- Roblox üzerine bas → Roblox açılır, overlay menü görünür
- **Player ESP** switch'ini aç

### 4. Script (Executor Gerekli)
Roblox başlatılınca `/sdcard/reaper_esp.lua` dosyası oluşur.
Bu scripti executor'una (Delta, Arceus X, vb.) yapıştır.

Script koordinatları UDP 127.0.0.1:7777'ye gönderir.
Overlay bu veriyi alır ve ESP çizer.

---

## ESP Özellikleri
- **Box** — beyaz kutu
- **Skeleton** — kırmızı kemik
- **Tracer** — ekran üstünden yeşil çizgi
- **HP Bar** — sol kenarda renk geçişli
- **İsim + Mesafe** — kutunun üstünde
- **Menzil** — 280 metre

---

## Teknik Mimari

```
ReaperEngine APK
├── LicenseActivity     → lisans doğrulama
├── DashboardActivity   → oyun listesi + script yazıcı
└── OverlayService
    ├── ESPCanvas       → Drawing (box/skeleton/tracer/hp)
    └── UDP:7777        ← Lua script buraya veri gönderir

Roblox içi Lua (executor ile çalışır)
└── RenderStepped → WorldToViewportPoint → UDP → OverlayService
```
